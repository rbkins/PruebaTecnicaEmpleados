"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Search, Download } from "lucide-react"

interface RecordsTableProps {
  records: any[]
  config: {
    fields: any[]
  }
}

export function RecordsTable({ records, config }: RecordsTableProps) {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredRecords = records.filter((record) =>
    Object.values(record).some((value) => value?.toString().toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const getFieldLabel = (fieldId: string) => {
    const field = config.fields.find((f) => f.id === fieldId)
    return field?.label || fieldId
  }

  const getDisplayValue = (fieldId: string, value: any) => {
    const field = config.fields.find((f) => f.id === fieldId)

    if (field?.type === "select" && field.options) {
      const option = field.options.find((opt) => opt.value === value)
      return option?.label || value
    }

    return value
  }

  const exportToCSV = () => {
    if (records.length === 0) return

    const headers = config.fields.map((field) => field.label).join(",")
    const rows = records
      .map((record) =>
        config.fields
          .map((field) => {
            const value = getDisplayValue(field.id, record[field.id])
            return `"${value || ""}"`
          })
          .join(","),
      )
      .join("\n")

    const csv = `${headers}\n${rows}`
    const blob = new Blob([csv], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "empleados.csv"
    a.click()
    window.URL.revokeObjectURL(url)
  }

  if (records.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground text-lg">No hay registros aún</p>
        <p className="text-muted-foreground text-sm mt-2">Los empleados registrados aparecerán aquí</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar empleados..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <Button onClick={exportToCSV} variant="outline" className="flex items-center gap-2 bg-transparent">
          <Download className="h-4 w-4" />
          Exportar CSV
        </Button>
      </div>

      <div className="rounded-md border">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">#</th>
                {config.fields.map((field) => (
                  <th key={field.id} className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">
                    {field.label}
                  </th>
                ))}
                <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">
                  Fecha de Registro
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredRecords.map((record, index) => (
                <tr key={record.id} className="border-b transition-colors hover:bg-muted/50">
                  <td className="p-4 align-middle">
                    <Badge variant="secondary">{index + 1}</Badge>
                  </td>
                  {config.fields.map((field) => (
                    <td key={field.id} className="p-4 align-middle">
                      {getDisplayValue(field.id, record[field.id]) || "-"}
                    </td>
                  ))}
                  <td className="p-4 align-middle text-sm text-muted-foreground">{record.timestamp}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="text-sm text-muted-foreground">
        Mostrando {filteredRecords.length} de {records.length} registros
      </div>
    </div>
  )
}
