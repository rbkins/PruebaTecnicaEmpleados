"use client"

import { useState, useEffect } from "react"
import { DynamicForm } from "@/components/dynamic-form"
import { RecordsTable } from "@/components/records-table"
import { ConfigPanel } from "@/components/config-panel"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Settings, Users, FileText } from "lucide-react"

// JSON inicial de configuración del formulario
const initialFormConfig = {
  fields: [
    {
      id: "nombres",
      label: "Nombres",
      type: "text",
      required: true,
      minLength: 2,
    },
    {
      id: "apellidos",
      label: "Apellidos",
      type: "text",
      required: true,
      minLength: 2,
    },
    {
      id: "email",
      label: "Correo Electrónico",
      type: "email",
      required: true,
    },
    {
      id: "telefono",
      label: "Teléfono",
      type: "tel",
      required: false,
    },
    {
      id: "genero",
      label: "Género",
      type: "select",
      required: true,
      options: [
        { value: "masculino", label: "Masculino" },
        { value: "femenino", label: "Femenino" },
        { value: "otro", label: "Otro" },
      ],
    },
    {
      id: "departamento",
      label: "Departamento",
      type: "select",
      required: true,
      options: [], // Se llenará desde la API
    },
    {
      id: "observaciones",
      label: "Observaciones",
      type: "textarea",
      required: false,
    },
  ],
}

export default function HomePage() {
  const [formConfig, setFormConfig] = useState(initialFormConfig)
  const [records, setRecords] = useState<any[]>([])
  const [departments, setDepartments] = useState([])

  // Simular API de departamentos
  useEffect(() => {
    const fetchDepartments = async () => {
      // Simulando una llamada a API
      const mockDepartments = [
        { value: "rrhh", label: "Recursos Humanos" },
        { value: "it", label: "Tecnología" },
        { value: "ventas", label: "Ventas" },
        { value: "marketing", label: "Marketing" },
        { value: "finanzas", label: "Finanzas" },
      ]

      setDepartments(mockDepartments)

      // Actualizar el campo departamento en la configuración
      setFormConfig((prev) => ({
        ...prev,
        fields: prev.fields.map((field) =>
          field.id === "departamento" ? { ...field, options: mockDepartments } : field,
        ),
      }))
    }

    fetchDepartments()
  }, [])

  const handleFormSubmit = (data: any) => {
    const newRecord = {
      id: Date.now(),
      ...data,
      timestamp: new Date().toLocaleString(),
    }
    setRecords((prev) => [...prev, newRecord])
  }

  const handleConfigUpdate = (newConfig: any) => {
    setFormConfig(newConfig)
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Sistema de Registro de Empleados</h1>
          <p className="text-muted-foreground">Formulario dinámico configurable para el registro de empleados</p>
        </div>

        <Tabs defaultValue="form" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="form" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Formulario
            </TabsTrigger>
            <TabsTrigger value="records" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Registros ({records.length})
            </TabsTrigger>
            <TabsTrigger value="config" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Configuración
            </TabsTrigger>
          </TabsList>

          <TabsContent value="form" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Registro de Empleado</CardTitle>
              </CardHeader>
              <CardContent>
                <DynamicForm config={formConfig} onSubmit={handleFormSubmit} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="records" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Registros de Empleados</CardTitle>
              </CardHeader>
              <CardContent>
                <RecordsTable records={records} config={formConfig} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="config" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Panel de Configuración</CardTitle>
              </CardHeader>
              <CardContent>
                <ConfigPanel config={formConfig} onConfigUpdate={handleConfigUpdate} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
