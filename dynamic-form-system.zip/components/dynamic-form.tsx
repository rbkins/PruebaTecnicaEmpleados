"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle } from "lucide-react"

interface FormField {
  id: string
  label: string
  type: string
  required: boolean
  minLength?: number
  options?: { value: string; label: string }[]
}

interface DynamicFormProps {
  config: {
    fields: FormField[]
  }
  onSubmit: (data: any) => void
}

export function DynamicForm({ config, onSubmit }: DynamicFormProps) {
  const [formData, setFormData] = useState<Record<string, any>>({})
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)

  const handleInputChange = (fieldId: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [fieldId]: value,
    }))

    // Limpiar error si existe
    if (errors[fieldId]) {
      setErrors((prev) => ({
        ...prev,
        [fieldId]: "",
      }))
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    config.fields.forEach((field) => {
      const value = formData[field.id]

      if (field.required && (!value || value.toString().trim() === "")) {
        newErrors[field.id] = `${field.label} es obligatorio`
      } else if (field.minLength && value && value.toString().length < field.minLength) {
        newErrors[field.id] = `${field.label} debe tener al menos ${field.minLength} caracteres`
      }
    })

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)

    try {
      // Simular delay de envío
      await new Promise((resolve) => setTimeout(resolve, 1000))

      onSubmit(formData)
      setFormData({})
      setShowSuccess(true)

      // Ocultar mensaje de éxito después de 3 segundos
      setTimeout(() => setShowSuccess(false), 3000)
    } catch (error) {
      console.error("Error al enviar formulario:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const renderField = (field: FormField) => {
    const hasError = !!errors[field.id]
    const value = formData[field.id] || ""

    switch (field.type) {
      case "textarea":
        return (
          <div key={field.id} className="space-y-2">
            <Label htmlFor={field.id} className="flex items-center gap-1">
              {field.label}
              {field.required && <span className="text-destructive">*</span>}
            </Label>
            <Textarea
              id={field.id}
              value={value}
              onChange={(e) => handleInputChange(field.id, e.target.value)}
              className={hasError ? "border-destructive" : ""}
              placeholder={`Ingrese ${field.label.toLowerCase()}`}
            />
            {hasError && <p className="text-sm text-destructive">{errors[field.id]}</p>}
          </div>
        )

      case "select":
        return (
          <div key={field.id} className="space-y-2">
            <Label htmlFor={field.id} className="flex items-center gap-1">
              {field.label}
              {field.required && <span className="text-destructive">*</span>}
            </Label>
            <Select value={value} onValueChange={(val) => handleInputChange(field.id, val)}>
              <SelectTrigger className={hasError ? "border-destructive" : ""}>
                <SelectValue placeholder={`Seleccione ${field.label.toLowerCase()}`} />
              </SelectTrigger>
              <SelectContent>
                {field.options?.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {hasError && <p className="text-sm text-destructive">{errors[field.id]}</p>}
          </div>
        )

      default:
        return (
          <div key={field.id} className="space-y-2">
            <Label htmlFor={field.id} className="flex items-center gap-1">
              {field.label}
              {field.required && <span className="text-destructive">*</span>}
            </Label>
            <Input
              id={field.id}
              type={field.type}
              value={value}
              onChange={(e) => handleInputChange(field.id, e.target.value)}
              className={hasError ? "border-destructive" : ""}
              placeholder={`Ingrese ${field.label.toLowerCase()}`}
            />
            {hasError && <p className="text-sm text-destructive">{errors[field.id]}</p>}
          </div>
        )
    }
  }

  return (
    <div className="space-y-6">
      {showSuccess && (
        <Alert className="border-primary bg-primary/10">
          <CheckCircle className="h-4 w-4 text-primary" />
          <AlertDescription className="text-primary">¡Empleado registrado exitosamente!</AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">{config.fields.map(renderField)}</div>

        <div className="flex justify-end pt-4">
          <Button type="submit" disabled={isSubmitting} className="min-w-32">
            {isSubmitting ? "Enviando..." : "Registrar Empleado"}
          </Button>
        </div>
      </form>
    </div>
  )
}
